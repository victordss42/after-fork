<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Events__Advanced_Functions__Register_Meta' );


	class Tribe_Register_Meta extends Tribe__Events__Advanced_Functions__Register_Meta {

	}